import ActivityTab from "./activity-tab";
import "./activity.scss";

export default function ActivityMain() {
  return <ActivityTab />;
}
