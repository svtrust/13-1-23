export default function Datepic() {
  return <div>Date</div>;
}
